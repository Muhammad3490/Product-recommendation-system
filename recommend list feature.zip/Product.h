#include <iostream>
#include <string>
using namespace std;

//Creating a class named product
class Product
{
public:
    Product();
    Product(string name,string category,int price,string colour);
    ~Product();
    string getName();
    string getCategory();
    int    getPrice();
    string getColour();
    void setColour(string colour);
    void setName(string name);
    void setCategory(string category);
    void setPrice(int price);




private:
    string colour;
    string name;
    int price;
    string category;
};

